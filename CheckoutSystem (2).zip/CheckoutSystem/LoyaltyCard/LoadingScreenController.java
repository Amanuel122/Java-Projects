package CheckoutSystem.LoyaltyCard;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;


public class  LoadingScreenController extends checkoutController {

    public Button Done;
    @FXML
   public void initialize() {

    }

    public void pressDone(ActionEvent event) {
    }


}







