package CheckoutSystem.Less8;

import javafx.scene.control.TextField;

public class ThankYouPage {
    public TextField changeReturnTF;

}
